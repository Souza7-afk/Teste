# References

- https://github.com/ErickWendel/editing-videos-nodejs-ffmpeg/blob/main/recorded/src/index.js
- https://github.com/ffmpegwasm/ffmpeg.wasm/tree/main
- https://blog.scottlogic.com/2020/11/23/ffmpeg-webassembly.html
- https://github.com/ColinEberhardt/ffmpeg-wasm-streaming-video-player/tree/main
- https://ffmpegwasm.netlify.app/docs/getting-started/usage/

- https://developer.chrome.com/articles/fetch-streaming-requests/
- https://stackoverflow.com/a/69400632/4087199

- https://github.com/scalarhq/videotranscode.space
- https://docs.modfy.video/docs/processing#client-side-caveats
- https://www.w3.org/2021/03/media-production-workshop/talks/slides/qiang-fu-video-transcoding.pdf
- https://www.w3.org/2021/03/media-production-workshop/talks/qiang-fu-video-transcoding.html
- https://www.gumlet.com/learn/video-transcoding-what-is-transcoding/
- https://imagekit.io/blog/video-transcoding/
- https://developer.chrome.com/articles/webcodecs/
- https://portal.gitnation.org/contents/pushing-the-limits-of-video-encoding-in-browsers-with-webcodecs

- https://www.w3.org/TR/webcodecs-codec-registry/
- https://github.com/w3c/webcodecs/blob/f3ec7c962db46c0f211b4548fd89623d05de90b6/explainer.md#codec-configuration
- https://w3c.github.io/webcodecs/#dictdef-videodecoderconfig
- https://github.com/nickdesaulniers/netfix/blob/67b684e5f5b26d222cb913dde5a6cc46f6a5353e/demo/bufferAll.html

- https://transform.tools/json-to-jsdoc
- https://github.com/thenickdude/webm-writer-js
- https://github.com/Vanilagy/mp4-muxer
- https://github.com/Vanilagy/webm-muxer

- https://github.com/vjeux/mp4-h264-re-encode/blob/3f912f3d1ed448e507466206375ed7a06819d2d1/mp4box.html#L50-L62

- https://developer.mozilla.org/en-US/docs/Web/API/VideoDecoder/configure
- https://developer.mozilla.org/en-US/docs/Web/API/EncodedVideoChunk